try:
    num1 = int(input("Enter the first number: "))
    num2 = int(input("Enter the second number: "))
    num3 = int(input("Enter the third number: "))
    total = num1 + num2 + num3
    print(total)
except ValueError:
    print("Invalid input. Please enter valid integers.")
except Exception as e:
    print(f"An error occurred: {e}")