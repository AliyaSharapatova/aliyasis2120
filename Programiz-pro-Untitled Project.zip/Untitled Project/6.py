try:
    n = int(input("Enter the number of schoolchildren: "))
    k = int(input("Enter the number of tangerines: "))
    
    whole_tangerines_per_student = k // n
    remaining_tangerines = k % n
    
    print(f"Each student gets {whole_tangerines_per_student} whole tangerines")
    print(f"{remaining_tangerines} whole tangerines remain in the basket")
except ValueError:
    print("Invalid input. Please enter valid integers.")
except ZeroDivisionError:
    print("Cannot divide by zero.")
except Exception as e:
    print(f"An error occurred: {e}")