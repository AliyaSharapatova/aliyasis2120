try:
    numbers = [4, 8, 15, 16, 23, 42]
    for num in numbers:
        print(num)
except Exception as e:
    print(f"An error occurred: {e}")