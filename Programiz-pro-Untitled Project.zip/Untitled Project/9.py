try:
    num = int(input("Enter a number: "))
    
    result = num << 1
    
    if result == 0:
        print("The result of << is zero")
    else:
        print(f"The result of << is {result}")
except ValueError:
    print("Invalid input. Please enter a valid integer.")
except Exception as e:
    print(f"An error occurred: {e}")