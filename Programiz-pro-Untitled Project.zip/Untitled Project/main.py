try:
    numbers = [4, 8, 15, 16, 23, 42]
    formatted_numbers = ' '.join(map(str, numbers))
    print(formatted_numbers)
except Exception as e:
    print(f"An error occurred: {e}")