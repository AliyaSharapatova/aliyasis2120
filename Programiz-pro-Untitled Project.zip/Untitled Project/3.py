try:
    first_number = int(input("Enter the first number: "))
    for i in range(first_number, first_number + 3):
        print(i)
except ValueError:
    print("Invalid input. Please enter a valid integer.")
except Exception as e:
    print(f"An error occurred: {e}")