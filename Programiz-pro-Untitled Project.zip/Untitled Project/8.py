try:
    population = int(input("Enter the population of the universe: "))
    
    if population % 2 == 0:
        survivors = population // 2
    else:
        survivors = (population // 2) + 1
    
    print(f"The number of survivors is {survivors}")
except ValueError:
    print("Invalid input. Please enter a valid integer for the population.")
except Exception as e:
    print(f"An error occurred: {e}")