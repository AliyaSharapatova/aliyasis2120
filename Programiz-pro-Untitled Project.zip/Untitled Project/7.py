try:
    number = int(input("Enter a four-digit number: "))
    
    thousands = number // 1000
    hundreds = (number % 1000) // 100
    tens = (number % 100) // 10
    units = number % 10
    
    print(f"The digit in the thousands position is {thousands}")
    print(f"The digit in the hundreds position is {hundreds}")
    print(f"The digit in the tens position is {tens}")
    print(f"The digit in the position of units is {units}")
except ValueError:
    print("Invalid input. Please enter a valid four-digit integer.")
except Exception as e:
    print(f"An error occurred: {e}")