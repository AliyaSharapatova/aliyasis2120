# Input the user's age as an integer
age = int(input("Enter your age: "))

# Check if the user's age is at least 18
if age >= 18:
    print("Access allowed")
else:
    print("Access denied")