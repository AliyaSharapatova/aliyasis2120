# Input the coordinates of the first cell
x1 = int(input())
y1 = int(input())

# Input the coordinates of the second cell
x2 = int(input())
y2 = int(input())

# Check if the rook can move from the first square to the second
if x1 == x2 or y1 == y2:
    print("YES")
else:
    print("NO")